import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../Auth/Auth";
import { useState } from "react";
import { useEffect } from "react";

function Login() {
	const {user, setUser, login } = useAuth();
	const [msg, setMsg] = useState("");
	const navigate = useNavigate();

	const handleSubmit = function (event) {
		event.preventDefault();
		let email = event.target.email.value;
		let password = event.target.password.value;
		login(email, password)
			.then((res) => res.json())
			.then((data) => {
				if (data.type === "error") {
					setMsg(<span className="text-danger"> {data.msg}</span>);
				} else {
					setUser(data);
					navigate("/home");
				}
			})
			.catch((err) => console.log(err));
		setTimeout(() => {
			setMsg("");
		}, 5000);
	};

	useEffect(() => {
		fetch("/auth/user", {
			method: "POST",
		})
			.then((res) => res.json())
			.then((data) => {
				if (data?._id) {
					setUser(data);
					navigate("/home");
				}
			})
			.catch((err) => console.log(err));
	}, []);

	return (
		<div className="container-fluid">
			<div
				className="row justify-content-center align-items-center"
				style={{ height: "98vh" }}
			>
				<div className="col-4 shadow p-5 text-center bg-white">
					<form onSubmit={handleSubmit}>
						<p className="fst-italic">{msg}</p>
						<input
							type="email"
							className="form-control form-control-sm mb-3"
							placeholder="Email"
							name="email"
							required
						/>
						<input
							type="password"
							className="form-control form-control-sm mb-3"
							placeholder="Password"
							name="password"
							required
						/>
						<button className="btn btn-primary btn-sm mb-3">
							Login
						</button>
						<p>
							<Link to="/register">Create an account</Link>
						</p>
					</form>
				</div>
			</div>
		</div>
	);
}

export default Login;
