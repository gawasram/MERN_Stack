import { useState } from "react";
import { useAuth } from "../Auth/Auth";

function Profile() {
	const { user } = useAuth();
	const [msg, setMsg] = useState("");
	const handleSubmit = function (event) {
		event.preventDefault();
		var data = new FormData();
		data.append("name", event.target.name.value);
		data.append("email", event.target.email.value);
		data.append("gender", event.target.gender.value);
		data.append("phone", event.target.phone.value);
		data.append("pic", event.target.pic.files[0]);
		//send data to the backend
		fetch("/user", {
			method: "PUT",
			body: data,
		})
			.then((res) => res.json())
			.then((data) => {
				if (data.type === "success") {
					setMsg(
						<span className="fst-italic text-success">
							<span class="material-icons-outlined">done</span>
							{data.msg}
						</span>
					);
				} else {
					setMsg(
						<span className="fst-italic text-danger">
							<span class="material-icons-outlined">close</span>
							{data.msg}
						</span>
					);
				}
			})
			.catch((err) => console.log(err));
	};
	return (
		<div className="container-fluid">
			<div className="row">
				<span className="fs-3 px-5 pt-3">Profile</span>
			</div>
			<div className="row">
				<div className="col-12 p-5">
					<div className="text-center mb-3">{msg}</div>
					<form onSubmit={handleSubmit}>
						<input
							type="text"
							name="name"
							className="form-control form-control-sm mb-3"
							placeholder="Enter name"
							defaultValue={user.name}
							required
						/>
						<input
							type="email"
							name="email"
							className="form-control form-control-sm mb-3"
							placeholder="Enter email"
							defaultValue={user.email}
							required
						/>
						<div className="mb-3">
							<span className="me-3">Gender: </span>
							<input
								type="radio"
								name="gender"
								className="me-2"
								value="male"
								defaultChecked={user.gender == "male"}
							/>
							Male
							<input
								type="radio"
								name="gender"
								className="ms-3 me-2"
								value="female"
								defaultChecked={user.gender == "female"}
							/>
							Female
							<input
								type="radio"
								name="gender"
								className="ms-3 me-2"
								value="Others"
								defaultChecked={user.gender == "others"}
							/>
							Others
						</div>
						<input
							type="text"
							name="phone"
							className="form-control form-control-sm mb-3"
							placeholder="Enter phone number"
							defaultValue={user.phone}
							required
						/>
						<input
							type="file"
							name="pic"
							className="form-control form-control-sm mb-5"
							placeholder="Upload picture"
						/>
						<div className="text-center">
							<button className="btn btn-primary btn-sm px-5">
								Save
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	);
}

export default Profile;
