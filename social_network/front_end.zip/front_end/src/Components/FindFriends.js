import {useState, useEffect} from "react"
import Person from "./Person"
function FindFriends() {
	const [persons, setPersons] = useState([]);

	useEffect(() => {
		fetch("/user/persons", {
			method: "POST",
		})
			.then((res) => res.json())
			.then((data) => {
				console.log(data)
				setPersons(data);
			})
			.catch((err) => console.log(err));
	},[]);

	return (
		<div className="container-fluid">
			<div className="row px-2">
				<span class="fs-3">Find Friends</span>
			</div>
			<div className="row justify-content-between mt-1">
				{persons.map(personData => <Person personData={personData}/>)}
			</div>
		</div>
	);
}
export default FindFriends;
