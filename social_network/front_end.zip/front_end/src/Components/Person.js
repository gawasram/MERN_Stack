import "../Style.css";
import {useState} from "react"
import {useAuth} from "../Auth/Auth"

function Person(props) {
	const {user} = useAuth()

	const checkRequestStatus = function(){
		var temp=user?.sentFriendRequest.filter(item => item.userId === props.personData._id)
		if(temp.length > 0){
			return true // user got the friend request
		}else{
			return false // havent sent friend requst
		}
	}

	const [reqStatus, setReqStatus] = useState(checkRequestStatus())

	const sendFriendRequst = function () {
		var data = {
			userId: props.personData._id,
		};
		fetch("/user/friendreq", {
			method: "POST",
			body: JSON.stringify(data),
			headers: {
				"content-type": "application/json",
			},
		})
			.then((res) => res.json())
			.then((data) => {
				if(data.type === "success"){
					setReqStatus(true)
				}
			})
			.catch((err) => console.log(err));
	};

	return (
		<div className="col-5 border shadow p-1">
			<div className="row">
				<div className="col-4">
					<img
						src={"/user/pic/" + props.personData.pic}
						className="person-pic"
					/>
				</div>
				<div className="col-6 ">
					<div className="fs-5 py-3">{props.personData.name}</div>
					<div>
					{
						reqStatus ? (<span className="text-small border p-2 bg-secondary text-white">Friend Request Sent</span>) :(<button
							className="btn btn-primary btn-sm text-small"
							onClick={sendFriendRequst}
						>
							Send Friend Request
						</button>)
					}
					</div>
				</div>
			</div>
		</div>
	);
}

export default Person;
