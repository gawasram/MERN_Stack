import { useState, useEffect } from "react";
import "../Style.css"

function FriendListItem(props) {
	return (
		<div className="d-flex">
			<div>
				<img src={"/user/pic/" + props?.friend?.pic} className="user-small-image rounded rounded-circle" alt="" />
			</div>
			<div className="align-self-center">
				<span className="ms-3">{props?.friend?.name}</span>
			</div>
		</div>
	);
}

function FriendList() {
	const [friendsList, setFriendsList] = useState([]);

	const getFriendsList = function () {
		fetch("/user/friendslist", {
			method: "GET",
		})
			.then((res) => res.json())
			.then((data) => setFriendsList(data))
			.catch((err) => console.log(err));
	};
	useEffect(() => {
		getFriendsList();
	}, []);

	return (
		<div className="container-fluid p-0">
			{friendsList.map((friend) => {
				return (
					<div className="row p-0">
						<div className="col-12 px-3 border bg-white">
							<FriendListItem friend={friend} />
						</div>
					</div>
				);
			})}
		</div>
	);
}
export default FriendList;
