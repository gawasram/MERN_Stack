import "../Style.css"
import {useAuth} from "../Auth/Auth"
import {Link, useNavigate} from "react-router-dom"

function Sidebar(){
	const {user,logout} = useAuth()
	const navigate = useNavigate()
	return <div className="container-fluid">
		<div className="row">
			<div className="col-12 pt-4 text-center">
				<img src={"/user/pic/"+user?.pic} className="img-fluid user-pic rounded-3"/>
			</div>
		</div>
		<div className="row">
			<div className="col-12 fs-3 text-center">{user.name}</div>
		</div>
		<div className="row">
			<div className="col-12 text-center">{user.email}</div>
		</div>
		<div className="row mt-5 ps-3">
			<nav className="nav flex-column">
				<Link className="nav-link" to="/home/profile">Profile</Link>
				<Link className="nav-link" to="/home/newsfeed">News Feed</Link>
				<Link className="nav-link" to="/home/post">Post</Link>
				<Link className="nav-link" to="/home/findfriends">Find Friends</Link>
				<Link className="nav-link" to="/home/friends">Friends</Link>
				<div className="nav-link pointer" onClick={()=>{logout().then(res => {
					navigate("/")
				})}}>Logout</div>
			</nav>
		</div>
	</div>
}

export default Sidebar;