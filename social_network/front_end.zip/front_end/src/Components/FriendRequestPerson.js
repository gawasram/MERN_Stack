import "../Style.css";
import {useState} from "react"
import {useAuth} from "../Auth/Auth"

function FriendRequestPerson(props) {
	
	const approveRequest = function(){
		fetch("/user/approvereq", {
			method : "POST",
			body : JSON.stringify(props.personData),
			headers :{
				"content-type" : "application/json"
			}
		})
		.then(res => res.json())
		.then(data => {
			console.log(data)
			if(data.type === "success"){
				props.getFriendsRequestList()
				props.getFriendsList()
			}
		})
		.catch(err => console.log(err))
	}


	return (
		<div className="col-5 border shadow p-1">
			<div className="row">
				<div className="col-4">
					<img
						src={"/user/pic/" + props.personData.pic}
						className="person-pic"
					/>
				</div>
				<div className="col-6 ">
					<div className="fs-5 py-3">{props.personData.name}</div>
					<div>
						<button
							className="btn btn-primary btn-sm text-small"
							onClick={ approveRequest}
						>
							Approve
						</button>
					</div>
				</div>
			</div>
		</div>
	);
}

export default FriendRequestPerson;
