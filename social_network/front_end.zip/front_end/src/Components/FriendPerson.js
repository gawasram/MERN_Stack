import "../Style.css";
import {useState} from "react"
import {useAuth} from "../Auth/Auth"

function FriendPerson(props) {
	
	return (
		<div className="col-5 border shadow p-1">
			<div className="row">
				<div className="col-4">
					<img
						src={"/user/pic/" + props.personData.pic}
						className="person-pic"
					/>
				</div>
				<div className="col-6 ">
					<div className="fs-5 py-3">{props.personData.name}</div>
					<div>
						
					</div>
				</div>
			</div>
		</div>
	);
}

export default FriendPerson;
