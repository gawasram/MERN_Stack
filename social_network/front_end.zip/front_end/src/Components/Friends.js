import { useState, useEffect } from "react";
import FriendRequestPerson from "./FriendRequestPerson";
import FriendPerson from "./FriendPerson";

function Friends() {
	const [friendRequestList, setFriendRequestList] = useState([]);
	const [friendsList, setFriendsList] = useState([]);

	const getFriendsRequestList = function () {
		fetch("/user/friendreqlist", {
			method: "GET",
		})
			.then((res) => res.json())
			.then((data) => setFriendRequestList(data))
			.catch((err) => console.log(err));
	};

	const getFriendsList = function () {
		fetch("/user/friendslist", {
			method: "GET",
		})
			.then((res) => res.json())
			.then((data) => setFriendsList(data))
			.catch((err) => console.log(err));
	};

	useEffect(() => {
		getFriendsRequestList();
		getFriendsList();
	}, []);

	return (
		<div className="container-fluid">
			<div className="row mt-1">
				<span className="fs-3">Friend Requests</span>
			</div>
			<div className="row justify-content-between mt-1">
				{friendRequestList.map((personData) => (
					<FriendRequestPerson
						personData={personData}
						getFriendsRequestList={getFriendsRequestList}
						getFriendsList={getFriendsList}
					/>
				))}
			</div>
			<div className="row mt-1 pt-2 border-top">
				<span className="fs-3">Friends</span>
			</div>
			<div className="row justify-content-between mt-1">
				{friendsList.map((personData) => (
					<FriendPerson personData={personData} />
				))}
			</div>
		</div>
	);
}

export default Friends;
