import { useRef, useState } from "react";
import "../Style.css";

function WritePost() {
	const [postText, setPostText] = useState("");
	const postImageRef = useRef();
	const [msg, setMsg] = useState("");
	const createPost = function () {
		var data = new FormData();
		data.append("postText", postText);
		data.append("postImage", postImageRef.current.files[0]);
		fetch("/post", {
			method: "POST",
			body: data,
		})
			.then((res) => res.json())
			.then((data) => {
				if (data.type === "success") {
					setMsg(
						<span className="fst-italic text-success">
							<span class="material-icons-outlined">done</span>
							{data.msg}
						</span>
					);
				} else {
					setMsg(
						<span className="fst-italic text-danger">
							<span class="material-icons-outlined">close</span>
							{data.msg}
						</span>
					);
				}
			}).catch(err => console.log(err))
	};

	return (
		<div className="container-fluid">
			<div className="row px-5 pt-3">
				<div className="col-12 fs-3">Write Post</div>
			</div>
			<div className="row p-5">
				<div className="text-center mb-3">{msg}</div>
				<div className="form-floating">
					<textarea
						className="form-control post-text"
						placeholder="Write post here"
						id="floatingTextarea"
						value={postText}
						onChange={(e) => setPostText(e.target.value)}
					></textarea>
					<label for="floatingTextarea" className="ms-3">
						Write Posts here
					</label>
				</div>
			</div>
			<div className="row px-5 mb-5">
				<label className="p-0 text-muted form-label">
					Post Images here
				</label>
				<input
					type="file"
					ref={postImageRef}
					className="form-control"
				/>
			</div>
			<div className="text-center">
				<button className="btn btn-primary px-5" onClick={createPost}>
					Save
				</button>
			</div>
		</div>
	);
}

export default WritePost;
