import Register from "./Components/Register";
import Login from "./Components/Login";
import Home from "./Components/Home";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./Style.css";
import { AuthContext } from "./Auth/AuthContext";
import { useState, useEffect } from "react";
import { login, logout } from "./Auth/Auth";
import Profile from "./Components/Profile";
import Newsfeed from "./Components/Newsfeed";
import WritePost from "./Components/WritePost";
import FindFriends from "./Components/FindFriends";
import Friends from "./Components/Friends";

const router = createBrowserRouter([
  { path: "/", element: <Login /> }, //Default path component
  {
    path: "/home",
    element: <Home />,
    children: [
      { path: "profile", element: <Profile /> },
      { path: "newsfeed", element: <Newsfeed /> },
      { path: "post", element: <WritePost /> },
      { path: "findfriends", element: <FindFriends /> },
      { path: "friends", element: <Friends /> },
    ],
  },
  { path: "/register", element: <Register /> },
]);

function App() {
  const [user, setUser] = useState(null);

  return (
    <>
      <AuthContext.Provider value={{ user, setUser, login, logout }}>
        <RouterProvider router={router} />
      </AuthContext.Provider>
    </>
  );
}

export default App;
