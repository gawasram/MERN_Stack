import {AuthContext} from "./AuthContext"
import {useContext} from "react"

export const login = function(email,password){
	return fetch("/auth/login",{
		method : "POST",
		body : JSON.stringify({email : email, password : password}),
		headers: {
			"content-type": "application/json"
		}
	})
}

export const logout = function(){
	return fetch("/auth/logout",{
		method : "POST",
	})
}

export const useAuth = function(){
	return useContext(AuthContext)
}